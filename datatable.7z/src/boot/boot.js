import table from '../components/datatable/index';
import checkbox from '../components/checkbox/index';
import ksutil from '../core/util/ksutil';
angular
    .element(document)
    .ready( function() {
        angular
            .module( 'app-bootstrap', ['material.core.theming','material.core.theming.palette',ksutil.name,table.name,checkbox.name] )
            .run(()=>{

                console.log(`APP START`);
            })
            .config(($mdThemingProvider)=>{
                "use strict";
                console.info($mdThemingProvider)
                $mdThemingProvider.theme('default')
                    .primaryPalette('green')
                    .accentPalette('lime');
            })
        ;

        let body = document.getElementsByTagName("body")[0];
        angular.bootstrap( body, [ 'app-bootstrap' ]);
    });
