/**
 * Created by huangsihuan on 2016/11/3.
 */
export default angular.module('material.core',[])
    .factory('$mdUtil' ,UtilFactory);



function UtilFactory(){
    "use strict";
    return {
        parseAttributeBoolean:function(value, negatedCheck) {
            return value === '' || !!value && (negatedCheck === false || value !== 'false' && value !== '0');
        },
        fakeNgModel: function() {
            return {
                $fake: true,
                $setTouched: angular.noop,
                $setViewValue: function(value) {
                    this.$viewValue = value;
                    this.$render(value);
                    this.$viewChangeListeners.forEach(function(cb) {
                        cb();
                    });
                },
                $isEmpty: function(value) {
                    return ('' + value).length === 0;
                },
                $parsers: [],
                $formatters: [],
                $viewChangeListeners: [],
                $render: angular.noop
            };
        },
    }
}


