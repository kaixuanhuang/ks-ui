import kscheckbox from './checkbox';
export default angular.module('ks.components.checkbox',[])
      .directive('ksCheckbox',kscheckbox);
