import ksTable from './datatable';
import ksColumn from './column';
import {fixLeftFilter,fixRightFilter} from './fixfilter';
import datatableService from './datatableService';
import tableUtilProvider from './tableUtil';
export default angular.module('ks.components.datatable',[])
 .directive('ksTable',ksTable)
 .directive('ksColumn',ksColumn)
 .filter('filterfixleft' ,fixLeftFilter)
 .filter('filterfixright' ,fixRightFilter)
 .service('datatableService' ,datatableService)
 .provider('$tableUtil',tableUtilProvider);
