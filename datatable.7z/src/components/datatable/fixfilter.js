export  function fixLeftFilter(){
  return function(colDefs){
    console.info('leftfilter' ,colDefs)
    var i = 0 ,l =colDefs.length;
    while(i < l){
      if(colDefs[i].fixed === 'true') i++;
      else {
         return Array.prototype.slice.call(colDefs,0,i);
      }
    }
    return colDefs;
  }
}


export  function fixRightFilter(){
  return function(colDefs){
    console.info('rightfilter' ,colDefs)
    var i,l;i = l =colDefs.length;
    while(i > 0){
      if(colDefs[i-1].fixed === 'true') i--;
      else {
         return Array.prototype.slice.call(colDefs,i,l);
      }
    }
    return colDefs;
  }
}
