export default function datatableService(){
  this.addScrollEvent = function(elm){
    if(!elm) return;
    var kstable = elm.querySelector('.ks-table-container');
    var fixlefttable = elm.querySelector('.ks-table-fixleft-container');
    var fixrighttable = elm.querySelector('.ks-table-fixright-container');
    console.info('fixlefttable' ,fixlefttable)
    kstable.addEventListener('scroll',function(e){
      e.preventDefault();
      var target = e.target ,scrollWidth,offsetWidth;
      var scrollWidth = target.scrollWidth;
      var offsetWidth = target.offsetWidth;
      var scrolldis = target.scrollLeft;
      var statusleft = scrolldis === 0;
      var statusright = (offsetWidth+scrolldis === scrollWidth);
      var statusmiddle = !(statusleft || statusright);
      if(statusleft){
          if(fixlefttable) fixlefttable.classList.remove('fix-shadow');
          if(fixrighttable) fixrighttable.classList.add('fix-shadow');
      }
      if(statusmiddle){
        if(fixlefttable) fixlefttable.classList.add('fix-shadow');
        if(fixrighttable) fixrighttable.classList.add('fix-shadow');
      }
      if(statusright){
        if(fixlefttable) fixlefttable.classList.add('fix-shadow');
        if(fixrighttable) fixrighttable.classList.remove('fix-shadow');
      }
    });
  }

}
